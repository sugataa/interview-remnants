During the technical interview, you'll be working with some existing code. This script will help verify that your enviorment is set up properly.

You will need Node 6.5.0 or newer.

To run the check script, first run:
  npm install

If that completes successfully, run:
  npm run check

This will print out an error message if there's a problem or "Everything working!" if you have set everything up correctly.
